</div><!-- /.row -->

</div><!-- /.container -->

<footer class="blog-footer">
    <p>Website Built By Violet and Team<.</p>
    <p><a href="#">Back to top</a></p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
