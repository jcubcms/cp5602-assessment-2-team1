</div><!-- /.row -->

</div><!-- /.container -->

<footer class="blog-footer">
    <p>Website Built By Team 01 </p>
    <a href="<?php echo site_url('');?>">Home</a>
    <a href="<?php echo site_url('/aboutus');?>">AboutUs</a>
    <a href="<?php echo site_url('/classes');?>">Courses</a>
    <a href="<?php echo site_url('/joinus');?>">JoinUs</a>
    <p><a href="#">Back to top</a></p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
